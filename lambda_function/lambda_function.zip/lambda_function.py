import json


def lambda_handler(event, context):
    body = "Hello, Lambda"
    return {"statusCode": 200, "body": json.dumps(body)}
